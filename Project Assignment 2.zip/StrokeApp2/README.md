# Group-8-Healthy-Brain-Stroke-Awareness
Team members: Ernest, David, Philip, Gabriela, and Mike. Topic: App for Healthy Brain: Stroke Awareness
